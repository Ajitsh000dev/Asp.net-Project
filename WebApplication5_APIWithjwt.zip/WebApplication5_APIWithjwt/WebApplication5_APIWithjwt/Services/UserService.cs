using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using WebApplication5_APIWithjwt.Identity;
using WebApplication5_APIWithjwt.Models;
using WebApplication5_APIWithjwt.ServiceContract;
using WebApplication5_APIWithjwt.Utility;
using WebApplication5_APIWithjwt.ViewModel;

namespace WebApplication5_APIWithjwt.Services
{
  public class UserService : IUserService
  {
    private readonly ApplicationUserManager _applicationUserManager;
    private readonly ApplicationSignInManager _applicationSignInManager;
   private readonly AppSettings _appSetting;
    private readonly ApplicationDbContext dbContext;

    public UserService(IOptions<AppSettings> appSetting, ApplicationUserManager applicationUserManager, ApplicationSignInManager applicationSignInManager, ApplicationDbContext applicationDbContext )
    {
      _applicationUserManager = applicationUserManager;
      _applicationSignInManager = applicationSignInManager;
     _appSetting = appSetting.Value;
      dbContext = applicationDbContext;
    }

    public async Task<ApplicationUser> Authenticate(LoginViewModel loginViewModel)
    {
      var applicationUser = await _applicationUserManager.FindByEmailAsync(loginViewModel.UserName);
      var result = await _applicationSignInManager.PasswordSignInAsync(applicationUser.UserName, loginViewModel.Password, false, false);
      if (result.Succeeded)
      {
        //var applicationUser = await _applicationUserManager.FindByEmailAsync(loginViewModel.UserName);

        applicationUser.PasswordHash = null;
      //  JWT Token
        //if (await _applicationUserManager.IsInRoleAsync(applicationUser, SD.Role_Admin))
        //  applicationUser.Role = SD.Role_Admin;
        //if (await _applicationUserManager.IsInRoleAsync(applicationUser, SD.Role_Employee))
        //  applicationUser.Role = SD.Role_Employee;

        //var tokenHandler = new JwtSecurityTokenHandler();
        //var key = System.Text.Encoding.ASCII.GetBytes(_appSetting.Secret);

        //var tokenDescriptor = new SecurityTokenDescriptor()
        //{
        //  Subject = new ClaimsIdentity(new Claim[]
        //  {
        //    new Claim(ClaimTypes.Name,applicationUser.Id),
        //    new Claim(ClaimTypes.Email,applicationUser.Email),
        //    new Claim(ClaimTypes.Role,applicationUser.Role)
        //  }),
        //  Expires = DateTime.UtcNow.AddHours(30),
        //  SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key),
        //  SecurityAlgorithms.HmacSha256Signature)
        //};

        //var token = tokenHandler.CreateToken(tokenDescriptor);
        //applicationUser.Token = tokenHandler.WriteToken(token);
        return applicationUser;
      }
      else
        return null;
    }

        public Task<bool> Logout()
        {
            var islogout = _applicationSignInManager.SignOutAsync();
            if (islogout.IsCompletedSuccessfully)
            {
                return null;
            }
            return null;
        }

        public async Task<bool> Register(Register register)
    {
      var user = new ApplicationUser()
      {
        UserName=register.Username,
        FirstName = register.FirstName,
        LastName = register.LastName,
        Email = register.Email,
        PhoneNumber=register.PhoneNumber,
        DOB=register.DOB,
        Gender=register.Gender,
        city=register.City,
        IsActiveORdeactive=register.IsActiveORdeactive
      };

      var result = await _applicationUserManager.CreateAsync(user, register.password);

      return Save();
    }
    public bool Save()
    {
      return dbContext.SaveChanges() == 1 ? true : false;
    }
  }
}
