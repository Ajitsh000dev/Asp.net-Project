using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication5_APIWithjwt.Identity;
using WebApplication5_APIWithjwt.Models;
using WebApplication5_APIWithjwt.ViewModel;

namespace WebApplication5_APIWithjwt.ServiceContract
{
  public interface IUserService
  {
    Task<ApplicationUser> Authenticate(LoginViewModel loginViewModel);
    Task<bool> Register(Register register);
    Task<bool> Logout();


    }
}
