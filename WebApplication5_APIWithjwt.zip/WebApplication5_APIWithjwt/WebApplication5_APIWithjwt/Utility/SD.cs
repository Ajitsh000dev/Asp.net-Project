using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication5_APIWithjwt.Utility
{
  public class SD
  {
    public const string Role_Admin = "Admin";
    public const string Role_Employee = "Employee";
  }
}
