using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication5_APIWithjwt.Models
{
  public class Subcategory
  {
    public int id { get; set; }
    public string SubCategoryName { get; set; }
    public int categoryid { get; set; }
    [ForeignKey("categoryid")]
    public Category category { get; set; }
  }
}
