using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication5_APIWithjwt.Models
{
  public class Register
  {
    [Required]
    public string Username { get; set; }
    [Required]
    public string FirstName { get; set; }
    [Required]
    public string LastName { get; set; }
    [Required]
    public string Email { get; set; }
    [Required]
    public string PhoneNumber { get; set; }
    [Required]
    public string password { get; set; }
    [Required]
    public string DOB { get; set; }
    [Required]
    public string City { get; set; }
    [Required]
    public string Gender { get; set; }
    [Required]
    public bool IsActiveORdeactive { get; set; }

    public string Token { get; set; }
    public string Role { get; set; }
  }
}
