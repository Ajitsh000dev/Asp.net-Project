using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication5_APIWithjwt.Models
{
  public class Products
  {
        public int id { get; set; }
        [Required]
        public string ProductName { get; set; }
        [Required]
        public string Discription { get; set; }
        [Required]
        public string productcode { get; set; }
        [Required]
        public double price { get; set; }
        public byte[] image { get; set; }
        public int? categoryid { get; set; }

        [Required]
        public int subcategoryid { get; set; }
        [ForeignKey("subcategoryid")]
        public Subcategory subcategory { get; set; }
       
    }
}
