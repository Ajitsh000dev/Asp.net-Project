using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication5_APIWithjwt.Models;

namespace WebApplication5_APIWithjwt.Identity
{
  public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
  {
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options)
    {

    }
    public DbSet<ApplicationRole> ApplicationRoles { get; set; }
    public DbSet<Employee> Employees { get; set; }
    public DbSet<Products> products { get; set; }
    public DbSet<Category> categories { get; set; }
    public DbSet<Subcategory> subcategories { get; set; }
    protected override void OnModelCreating(ModelBuilder builder)
    {
      base.OnModelCreating(builder);
    }
  }
}
