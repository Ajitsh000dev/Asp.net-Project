﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication5_APIWithjwt.Models;

namespace WebApplication5_APIWithjwt.Repository.IRepository
{
   public interface IProductRepository
    {
        ICollection<Products> Getproducts();
        ICollection<Category> getproductbycategory(int id);
        Products getproduct(int id);
        bool Createproducts(Products products);
        bool updateproducts(Products products);
        bool Deleteproducts(Products products);
        bool Save();
    }
}
