﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication5_APIWithjwt.Identity;
using WebApplication5_APIWithjwt.Models;
using WebApplication5_APIWithjwt.Repository.IRepository;

namespace WebApplication5_APIWithjwt.Repository
{
    public class ProductRepository:IProductRepository
    {
        private readonly ApplicationDbContext _context;
        public ProductRepository(ApplicationDbContext applicationDbContext)
        {
            _context = applicationDbContext;
        }

        public bool Createproducts(Products products)
        {
            var blogs = _context.products.Add(products);
            return Save();
        }

        public bool Deleteproducts(Products products)
        {
            _context.Remove(products);
            return Save();
        }

        public ICollection<Category> getproductbycategory(int id)
        {
            return (ICollection<Category>)_context.products.Include(t => t.categoryid).
                Where(s => s.categoryid == id).ToList();
        }

        public Products getproduct(int id)
        {
            return _context.products.FirstOrDefault(np => np.id == id);

        }

        public ICollection<Products> Getproducts()
        {
            //var products = _context.products.Include(t => t.subcategory).Include(n => n.subcategory.categoryid).ToList();
            var products = _context.products.ToList();

            return (products);
        }

        public bool Save()
        {
            return _context.SaveChanges() == 1 ? true : false;
        }

        public bool updateproducts(Products products)
        {
            _context.products.Update(products);
            return Save();
        }
    }
}
