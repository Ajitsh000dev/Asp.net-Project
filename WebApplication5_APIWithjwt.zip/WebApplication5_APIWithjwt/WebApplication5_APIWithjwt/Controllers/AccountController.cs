using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication5_APIWithjwt.Identity;
using WebApplication5_APIWithjwt.Models;
using WebApplication5_APIWithjwt.Models.ModelDTO;
using WebApplication5_APIWithjwt.ServiceContract;
using WebApplication5_APIWithjwt.ViewModel;

namespace WebApplication5_APIWithjwt.Controllers
{
    [ApiController]
    public class AccountController : Controller
    {
        private readonly IUserService _userService;
        private readonly ApplicationSignInManager _applicationSignInManager;
        public AccountController(IUserService userService, ApplicationSignInManager applicationSignInManager)
        {
            _userService = userService;
            _applicationSignInManager = applicationSignInManager;
        }
        [Route("authenticate")]
        [HttpPost]
        public async Task<IActionResult> Authenticate([FromBody] LoginViewModel loginViewModel)
        {
            var user = await _userService.Authenticate(loginViewModel);
            if (user == null)
                return BadRequest(new { message = "Username or Password is incorrect" });
            return Ok(user);
        }
        [Authorize]
        [Route("Registration")]
        [HttpPost]
        public async Task<IActionResult> Registration([FromBody] RegisterDTO register)
        {
            Register register1 = new Register();
            register1.Username = register.Username;
            register1.FirstName=register.FirstName;
            register1.LastName = register.LastName;
            register1.Email = register.Email;
            register1.PhoneNumber = register.PhoneNumber;
            register1.password = register.password;
            register1.DOB = register.DOB;
            register1.City = register.City;
            register1.Gender = register.Gender;
            register1.IsActiveORdeactive = register.IsActiveORdeactive;
            var abcd = await _userService.Register(register1);
            return Ok();
        }
        [Route("api/Logout")]
        [HttpGet]
        public IActionResult Logout()
        {
            _userService.Logout();
            return Ok();
        }
    }
}
