﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication5_APIWithjwt.Models;
using WebApplication5_APIWithjwt.Repository.IRepository;

namespace WebApplication5_APIWithjwt.Controllers
{
    [Route("api/products")]
    [ApiController]
    public class ProductController : Controller
    {
        private readonly IProductRepository productRepository;
         //private readonly IMapper _mapper;

        public ProductController(IProductRepository product)
        {
            productRepository = product;
        }
        [HttpGet]

        public IActionResult Index()
        {
            var products = productRepository.Getproducts().ToList();

            return Ok(products); // 200
        }
        [HttpPost]
        public IActionResult Createproduct([FromBody] Products products)
        {
            if (products == null)
                return BadRequest(ModelState);
            //  var nationalPark = _mapper.Map<NationalParkDto, NationalPark>(nationalParkDto);
           // var products1 = _mapper.Map<Products>(products);
            if (!productRepository.Createproducts(products))
            {
                ModelState.AddModelError("", $"Something went wrong while save data ");
                return StatusCode(StatusCodes.Status500InternalServerError, ModelState);
            }
            return Ok(); //200
                         // return CreatedAtRoute("GetNationalPark", new { nationalParkId = nationalPark.Id }, nationalPark);
        }
    }
}
