﻿var dataTable;

$(document).ready(function () {
    loadDataTable();
})

function loadDataTable() {
    dataTable = $('#tblData').DataTable({
        "ajax": {
            "url": "Product/GetAll",
            "type": "GET",
            "datatype": "json"
        },
        "columns": [
            { "data": "ProductName", "width": "40%" },
            { "data": "Discription", "width": "40%" },
            { "data": "price", "width": "40%" },
            { "data": "category", "width": "40%" },
            { "data": "subcategory", "width": "40%" },

            {
                "data": "id",
                "render": function (data) {
                    return `
                            <div class="text-center">
                                <a href="Product/Upsert/${data}" class="btn btn-info">
                                <i class="fas fa-edit"></i>
                                </a>
                                <a href=Delete("Product/Delete/${data}") class="btn btn-danger">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </div>
                            `;
                }
            }
        ]
    })
}