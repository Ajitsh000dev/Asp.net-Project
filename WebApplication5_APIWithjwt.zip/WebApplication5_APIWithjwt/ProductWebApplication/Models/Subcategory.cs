﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductWebApplication.Models
{
    public class Subcategory
    {
        public int id { get; set; }
        public string SubCategoryName { get; set; }
        public int categoryid { get; set; }
        public Category category { get; set; }
    }
}
