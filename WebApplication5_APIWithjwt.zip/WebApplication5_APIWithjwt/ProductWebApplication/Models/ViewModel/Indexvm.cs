﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductWebApplication.Models.ViewModel
{
    public class Indexvm
    {
        public IEnumerable<Products> productslist { get; set; }
        public IEnumerable<Category> categorieslist { get; set; }
        public IEnumerable<Subcategory>subcategories { get; set; }
        public Category category { get; set; }
        public Subcategory subcategory { get; set; }
        public Products products { get; set; }

    }
}
