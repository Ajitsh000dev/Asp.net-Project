﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductWebApplication.Models.ViewModel
{
    public class Productvm
    {
        public Products Product { get; set; }
        //public IEnumerable<Category> CategoryList{ get; set; }
        public IEnumerable<SelectListItem> CategoryList { get; set; }
        //public IEnumerable<CoverType> CoverTypeList { get; set; }
        public IEnumerable<SelectListItem> SubCategoryList { get; set; }
    }
}
