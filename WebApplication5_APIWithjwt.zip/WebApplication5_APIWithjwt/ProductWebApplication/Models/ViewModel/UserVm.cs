﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductWebApplication.Models.ViewModel
{
    public class UserVm
    {
        public AccountUser accountUser { get; set; }
        public string Genders { get; set; }
        public List<SelectListItem> Gendersby { get; } = new List<SelectListItem>
        {
            new SelectListItem { Value = "Male", Text = "Male" },
            new SelectListItem { Value = "Female", Text = "Female" },
        };
    }
}
