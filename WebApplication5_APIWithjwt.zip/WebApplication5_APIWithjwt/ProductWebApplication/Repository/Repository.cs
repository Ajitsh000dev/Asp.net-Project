﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using ProductWebApplication.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ProductWebApplication.Repository
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ISession _session;

        //public Repository(IHttpClientFactory httpClientFactory)
        //{
        //    HttpClientFactory = httpClientFactory;
        //}

        public Repository(IHttpClientFactory httpClientFactory, IHttpContextAccessor httpContextAccessor)
        {
            _httpClientFactory = httpClientFactory;
            _session = httpContextAccessor.HttpContext.Session;
        }

        public IHttpClientFactory HttpClientFactory { get; }

        public async Task<T> AuthenticateAsync(string url, T objToCreate)
        {

            var request = new HttpRequestMessage(HttpMethod.Post, url);
            if (objToCreate != null)
            {
                request.Content = new StringContent(JsonConvert.SerializeObject(objToCreate), Encoding.UTF8, "application/json");
            }

            var client = _httpClientFactory.CreateClient();
            HttpResponseMessage response = await client.SendAsync(request);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var jsonString = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<T>(jsonString);
            }
            return null;

        }

        public async Task<bool> CreateAsync(string url, T objToCreate)
        {

            var request = new HttpRequestMessage(HttpMethod.Post, url);
            //var abcd = _session.GetString(SD.session);
            //request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", abcd);
            if (objToCreate != null)
            {
                request.Content = new StringContent(JsonConvert.SerializeObject(objToCreate), Encoding.UTF8, "application/json");
            }

            var client = _httpClientFactory.CreateClient();
            HttpResponseMessage response = await client.SendAsync(request);
            if (response.StatusCode == System.Net.HttpStatusCode.Created)
                return true;
            else
                return false;
        }

        public async Task<bool> DeleteAsync(string url, int id)
        {
            var request = new HttpRequestMessage(HttpMethod.Delete, url + id.ToString());
            //var abcd = _session.GetString(SD.session);
            //request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", abcd);
            var client = _httpClientFactory.CreateClient();
            HttpResponseMessage response = await client.SendAsync(request);
            if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
                return true;
            else
                return false;
        }

        public async Task<IEnumerable<T>> GetAllAsync(string url)
        {
            if (_session == null)
            {

                var request = new HttpRequestMessage(HttpMethod.Get, url);
                //var abcd = _session.GetString(SD.session);
                //request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", abcd);
                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<IEnumerable<T>>(jsonString);
                }
                return null;
            }
            else
            {

                //var abcd = _session.GetString(SD.session);
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                var cookisre = new HttpContextAccessor();
                //var abxdddk = cookisre.HttpContext.Request.Cookies[SD.Cookiesdata];
                //if (abxdddk != null)
                //    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", abxdddk);

                //request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", abcd);
                // request.Headers.Authorization()
                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response = await client.SendAsync(request);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<IEnumerable<T>>(jsonString);
                }
                return null;
            }

        }

        public async Task<T> GetAsync(string url, int id)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, url + id.ToString());
            //var abcd = _session.GetString(SD.session);
            //request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", abcd);
            var client = _httpClientFactory.CreateClient();
            HttpResponseMessage response = await client.SendAsync(request);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var jsonString = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<T>(jsonString);
            }
            return null;
        }

        public async Task<IEnumerable<T>> Gettrailbynationalpark(string url, int id)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, url + id.ToString());
            //var abcd = _session.GetString(SD.session);
            //request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", abcd);
            var client = _httpClientFactory.CreateClient();
            HttpResponseMessage responseMessage = await client.SendAsync(request);
            if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var jsonstring = await responseMessage.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<IEnumerable<T>>(jsonstring);
            }
            return null;
        }

        public async Task<bool> UpdateAsync(string url, T objToUpate)
        {
            var request = new HttpRequestMessage(HttpMethod.Put, url);

            if (objToUpate != null)
            {
                request.Content = new
                StringContent(JsonConvert.SerializeObject(objToUpate), Encoding.UTF8, "application/json");
            }
            //var abcd = _session.GetString(SD.session);
            //request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", abcd);
            var client = _httpClientFactory.CreateClient();
            HttpResponseMessage response = await client.SendAsync(request);
            if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
                return true;
            else
                return false;
        }
    }
}

