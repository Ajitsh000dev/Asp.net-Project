﻿using Microsoft.AspNetCore.Http;
using ProductWebApplication.Models;
using ProductWebApplication.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace ProductWebApplication.Repository
{
    public class ProductRepository: Repository<Products>, IProductRepository
    {
        private readonly IHttpClientFactory _httpClientFactory;
        //private readonly ISession _session;

        public ProductRepository(IHttpClientFactory httpClientFactory, IHttpContextAccessor httpContextAccessor) : base(httpClientFactory, httpContextAccessor)
        {
            _httpClientFactory = httpClientFactory;
            //_session = httpContextAccessor.HttpContext.Session;
        }
    }
}
