﻿using Microsoft.AspNetCore.Mvc;
using ProductWebApplication.Models;
using ProductWebApplication.Models.ViewModel;
using ProductWebApplication.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductWebApplication.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAccountUserRepository _accountUserRepository;
        public AccountController(IAccountUserRepository accountUser)
        {
            _accountUserRepository = accountUser;
        }
        public IActionResult Login()
        {
            var userLogin = new Loginvm();
            return View(userLogin);
        }
        [HttpPost]
        public async Task<IActionResult> Login(AccountUser account)
        {
                var userdetails = await _accountUserRepository.AuthenticateAsync(SD.authentication, account);
                if (userdetails == null)
                {
                    //ViewData["Message"] = "Please put Valid Loginid Password";

                    return RedirectToAction("Login");
                }
               
                return RedirectToAction("Index", "Home");
        }
        public async Task<IActionResult> Register()
        {


            UserVm uservmVM = new UserVm()
            {
                accountUser = new AccountUser(),
            };
            return View(uservmVM);
        }
        [HttpPost]
        public async Task<IActionResult> Register(AccountUser accountUser)
        {
            var abcd = await _accountUserRepository.CreateAsync(SD.Registeruser, accountUser);
            // await _userrepository.AuthenticateAsync(SD.Register, userVm.user);
            //return RedirectToAction();
            return RedirectToAction("Login");


        }
        public async Task<IActionResult>  Logout()
        {
            await _accountUserRepository.GetAllAsync(SD.logout);
            return Ok();
        }
    }
}
