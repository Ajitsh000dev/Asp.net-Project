﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ProductWebApplication.Models;
using ProductWebApplication.Models.ViewModel;
using ProductWebApplication.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ProductWebApplication.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository _product;
        private readonly ICategoryRepository _category;

        public ProductController(IProductRepository productRepository,ICategoryRepository categoryRepository)
        {
            _product = productRepository;
            _category = categoryRepository;
        }
        public IActionResult Index()
        {
            return View();
        }
        public async Task<IActionResult> GetAll()
        {
            //var abcd =this.HttpContext.Session.GetString(SD.session);
            //if(abcd != null)
            //{
            //    return RedirectToAction("Index");
            //}

            return Json(new { data = await _product.GetAllAsync(SD.products) });
        }

        public async Task<IActionResult> Upsert(int? id)
        {
            //IEnumerable<Category> categories = _category.GetAllAsync(SD.products);
            //IEnumerable<Category> categories = _category.GetAllAsync(SD.products);

            //Productvm productVM = new ProductVM()
            //{
            //    Product = new Products(),
            //    CategoryList = categories;
            //    CoverTypeList = _unitOfWork.coverType.GetAll().Select(ct => new SelectListItem()
            //    {
            //        Text = ct.Name,
            //        Value = ct.Id.ToString()
            //    })
            //};
            //if (id == null)
            //    return View(productVM);
            //productVM.Product = _unitOfWork.Product.Get(id.GetValueOrDefault());
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Upsert(Products products)
        {
            if (ModelState.IsValid)
            {
                var files = HttpContext.Request.Form.Files;
                if (files.Count > 0)
                {
                    byte[] p1 = null;
                    using (var fs1 = files[0].OpenReadStream())
                    {
                        using (var ms1 = new MemoryStream())
                        {
                            fs1.CopyTo(ms1);
                            p1 = ms1.ToArray();
                        }
                    }
                    products.image = p1;
                }
                else
                {
                    var objFromDb = await _product.GetAsync
                        (SD.products, products.id);
                    products.image = objFromDb.image;
                }
                if (products.id == 0)
                {
                    await _product.CreateAsync(SD.products, products);
                }
                else
                {
                    await _product.UpdateAsync(SD.products + products.id, products);
                }
                return RedirectToAction(nameof(Index));
            }
            else
            {
                return View(products);
            }
        }
    }
}
