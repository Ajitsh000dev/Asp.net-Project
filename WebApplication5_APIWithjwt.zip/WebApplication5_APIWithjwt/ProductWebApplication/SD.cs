﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductWebApplication
{
    public static class SD
    {
        public static string APIBaseUrl = "https://localhost:44356/";

        public static string authentication = APIBaseUrl + "authenticate/";
        public static string Registeruser = APIBaseUrl + "Registration/";
        public static string products = APIBaseUrl + "api/Products";
        public static string logout = APIBaseUrl + "api/Logout";


    }
}
