﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookShpping_Project2.Utility
{
   public class StripeSettings
    {
        public string Publishablekey { get; set; }
        public string Secretkey { get; set; }
    }
}
