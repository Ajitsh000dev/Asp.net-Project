﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BookShopping_Project2.DataAccess.Migrations
{
    public partial class AddCategoryTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
