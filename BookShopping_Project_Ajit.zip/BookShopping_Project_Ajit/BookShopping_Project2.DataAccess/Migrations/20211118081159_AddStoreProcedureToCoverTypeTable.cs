﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BookShopping_Project2.DataAccess.Migrations
{
    public partial class AddStoreProcedureToCoverTypeTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"CREATE PROCEDURE SP_CoverType_Create
    
             @Name varchar(50)
             as
             insert CoverTypes(Name) values(@Name)
    ");
            migrationBuilder.Sql(@"CREATE PROCEDURE SP_CoverType_Update
            @Id int,
             @Name varchar(50)
             as
             update CoverTypes set Name=@Name where Id=@Id
    ");
            migrationBuilder.Sql(@"CREATE PROCEDURE SP_CoverType_Delete
             @Id int
             as
             delete CoverTypes where Id=@Id
    ");
            migrationBuilder.Sql(@"CREATE PROCEDURE SP_CoverType_GetCoverTypes
             as
             select * from CoverTypes
    ");
            migrationBuilder.Sql(@"CREATE PROCEDURE SP_CoverType_GetCoverType
             @Id int
             as
             select * from CoverTypes where Id=@Id
    ");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
