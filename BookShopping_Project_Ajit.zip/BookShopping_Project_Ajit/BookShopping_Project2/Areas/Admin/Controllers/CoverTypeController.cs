﻿using BookShopping_Project2.DataAccess.Repository.IRepository;
using BookShopping_Project2.Models;
using BookShpping_Project2.Utility;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookShopping_Project2.Areas.Admin.Controllers
{
    [Area("Admin")]
    //[Authorize(Roles = Sd.Role_Admin)]
    public class CoverTypeController : Controller
    {
        private readonly IUnitOfWork _unitofWork;
        public CoverTypeController(IUnitOfWork unitOfWork)
        {
            _unitofWork = unitOfWork;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Upsert(int?id)
        {
            CoverType coverType = new CoverType();
            if (id == null)
                return View(coverType);
            var param = new DynamicParameters();
            param.Add("@Id", id.GetValueOrDefault());
            coverType = _unitofWork.SP_CALL.OneRecord<CoverType>(Sd.Proc_CoverType_GetCoverType, param);
            //coverType = _unitofWork.coverType.Get(id.GetValueOrDefault());
            if (coverType == null)
                return NotFound();
            return View(coverType);
        }
        [HttpPost]
        public IActionResult Upsert(CoverType coverType)
        {
            if (coverType == null)
            return NotFound();
            if (!ModelState.IsValid)
            return View(coverType);
            var param = new DynamicParameters();
            param.Add("@Name", coverType.Name);
            if (coverType.Id == 0)
            {
                _unitofWork.SP_CALL.Execute(Sd.Proc_CoverType_Create, param);
            }
            //_unitofWork.coverType.Add(coverType);
            else
            {
                param.Add("@Id", coverType.Id);
                _unitofWork.SP_CALL.Execute(Sd.Proc_CoverType_Update, param);
            }
                //_unitofWork.coverType.Update(coverType);
                //_unitofWork.Save();
                return RedirectToAction(nameof(Index));
        }
        #region APIs
        [HttpGet]
        public IActionResult GetAll()
        {
            return Json(new { data = _unitofWork.SP_CALL.List<CoverType>(Sd.Proc_CoverType_GetCoverTypes) });
            //return Json(new { data = _unitofWork.coverType.GetAll() });
        }
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var coverTypeInDb = _unitofWork.coverType.Get(id);
            if (coverTypeInDb == null)
                return Json(new { success = false, message = "Error while deleting data!!!" });
            var param = new DynamicParameters();
            param.Add("@Id", id);
            _unitofWork.SP_CALL.Execute(Sd.Proc_CoverType_Delete, param);
           // _unitofWork.coverType.Remove(coverTypeInDb);
            //_unitofWork.Save();
            return Json(new { success = true, message = "Data Succesfully Deleted!!!" });
        }
        #endregion
    }
}
